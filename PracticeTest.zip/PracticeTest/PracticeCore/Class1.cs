﻿namespace PracticeCore
{
    public class Class1
    {

    }
}